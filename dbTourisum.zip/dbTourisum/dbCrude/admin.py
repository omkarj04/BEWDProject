from django.contrib import admin
from .models import user1
admin.site.register(user1)

